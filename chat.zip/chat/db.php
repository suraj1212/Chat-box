<?php 
$host = 'localhost';
$user = 'root';
$password = 'suraj123';
$db_name = 'chat';


  $db = new mysqli($host,$user,$password,$db_name);


?>