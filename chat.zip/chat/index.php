<!doctype html>
<?php include 'db.php'; ?>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" a href="style.css">
</head>

<body>
<div id="container">
  <div id="chat_box">
  <?php 
     $query = "SELECT * FROM chat ";
	 $run = $db->query($query);
	 
	 while($row = $run->fetch_array()) : 
  
  ?>
     <div class="chat_data">
     <span><?php echo $row['name']; ?>:</span>
     <span><?php echo $row['msg']; ?></span>
     <span><?php echo $row['time']; ?></span>
     </div>
     <?php endwhile; ?>
     </div>
     <form action="index.php" method="post">
     <input type="text" name="name" placeholder="Enter your name">
     <input type="text" name="msg" placeholder="enter your message">
     <input type="submit" value="send" name="submit">
     </form>
  
 <?php 
		if(isset($_POST['submit'])){ 
		
		$name = $_POST['name'];
		$msg = $_POST['msg'];
		
		$query = "INSERT INTO chat ('name', 'msg') values ('$name','$msg')";
		
		$run = $db->query($query);
		
		if($run){
			echo "<embed loop='false' src='facebookch_okcfjlrb.mp3' hidden='true' autoplay='true'/>";
		}
		
		
		}
		?>
  
  
</div>
</body>
</html>